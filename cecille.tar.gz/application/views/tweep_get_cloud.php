
<h2>Cloud words</h2>
<?php echo $cloud ?>