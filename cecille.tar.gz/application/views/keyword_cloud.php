
<h3>Cloud words</h3>
<?php
echo $cloud?>