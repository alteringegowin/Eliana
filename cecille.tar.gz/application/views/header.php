<div id="header">
    <div class="hdrl"></div>
    <div class="hdrr"></div>

    <h1><a href="<?php echo site_url() ?>"><?php echo $this->config->item('app_title'); ?></a></h1>

    <ul id="nav">
        <li><a href="<?php echo site_url('') ?>">Dashboard</a></li>
        <li><a href="<?php echo site_url('keyword') ?>">Keywords</a></li>
        <li><a href="<?php echo site_url('tweep') ?>">Tweep</a></li>
        <li><a href="<?php echo site_url('engine') ?>">Engine</a></li>
    </ul>
</div>