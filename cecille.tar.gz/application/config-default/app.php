<?php
$config['app_themes'] = 'backends';
$config['app_title'] = 'Elliana';