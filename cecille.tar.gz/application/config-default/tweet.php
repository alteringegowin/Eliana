<?php

	$config['tweet_consumer_key'] = "SaPLMIy3QQrop4obnh2BA";
	$config['tweet_consumer_secret'] = "TxCeLpB1K7JsJewetdo9h9lFQtKgwusr4dC1vsjHc";
