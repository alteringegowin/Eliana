<?php
$config['tweet_consumer_key'] = "SaPLMIy3QQrop4obnh2BA";
$config['tweet_consumer_secret'] = "TxCeLpB1K7JsJewetdo9h9lFQtKgwusr4dC1vsjHc";

$config['oauth_token'] = "26401725-P4ahcQRodpuFS7GYSMKDCTLszhz0HBPTZMo4F9fkc";
$config['oauth_token_secret'] = "D3gnjQHxV3y9pVeqrh1Qo63ZkxB5lwQWlwg1YjKaOo";
