<?php
$config['engine_url_start'] = 'http://192.168.100.234/140dev/db/startengine.php';
$config['engine_url_stop'] = 'http://192.168.100.234/140dev/db/stopengine.php';
