<?php

class Cli extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('tweep');
    }

    function index() {
        
    }

    function count_rt() {
        $sql = "
        SELECT 
        *
        FROM `tweets` 
        WHERE screen_name = 'lalights'
            AND  DATEDIFF(NOW(),created_at)  < 3
            AND tweet_text NOT LIKE '@%'
        ";
        $res = $this->db->query($sql)->result();

        foreach ($res as $r) {
            $text = character_limiter($r->tweet_text, 30, '');
            $RT = 'RT @' . $r->screen_name;
            $sql = "
            SELECT 
                COUNT( tweets.tweet_id ) AS total
            FROM tweet_mentions
            LEFT JOIN tweets ON tweets.tweet_id = tweet_mentions.tweet_id AND tweet_mentions.target_user_id=" . $r->user_id . "
            WHERE tweets.tweet_text  LIKE '%" . $this->db->escape_like_str($RT) . "%" . $this->db->escape_like_str($text) . "%'";
            $row = $this->db->query($sql)->row();
            xdebug($row);
        }
    }

}
