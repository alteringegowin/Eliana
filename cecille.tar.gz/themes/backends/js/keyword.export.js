$(function () {
    
    $(".datepicker").datetimepicker({
        dateFormat:'yy-mm-dd'
    });
    $(".timepicker").timepicker({});

	
});
